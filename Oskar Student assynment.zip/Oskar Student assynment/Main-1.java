import java.util.ArrayList;

public class Main { public static void main(String[] args) {

    try {
        // Read student records from the file
        Read reader = new Read("Student.txt");
        ArrayList<Student> students = reader.readrecords();

        // Check whether the file contains students
        if (students.isEmpty()) {
            System.out.println("No student records found.");
            return;
        }

        // Display all student records
        System.out.println("===== All Student Records =====");

        for (Student s : students) {
            System.out.println(s);
            System.out.println("GPA: " + s.gpacalculator());
            System.out.println("------------------------------");
        }

        // Find the star student
        Oskar oskar = new Oskar();
        Student star = oskar.findstarStudent(students);

        // Display the star student
        System.out.println("\n===== Star Student =====");
        System.out.println(star);
        System.out.println("GPA: " + star.gpacalculator());

    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}


}