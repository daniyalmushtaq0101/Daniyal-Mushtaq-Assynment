import java.util.ArrayList;
public class Oskar {
    private Student  starStudent;
    public Student findstarStudent(ArrayList<Student> student){
        Student starStudent=student.get(0);
        for(Student s: student){
            if(s.gpacalculator()>starStudent.gpacalculator()){
                starStudent=s;
            }
        }
        return starStudent;
    }
  //  public void displaystarStudent(){
    //    return  starStudent.toString();
    //}
}
