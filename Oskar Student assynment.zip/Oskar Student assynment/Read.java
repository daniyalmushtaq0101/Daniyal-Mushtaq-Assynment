import java.util.*;
import java.io.*;
public class Read {
    private String filename;
    public Read(String filename){
        this.filename=filename;
    }
    public ArrayList<Student> readrecords() throws FileNotFoundException{
        ArrayList<Student> students=new ArrayList<>();
        Scanner file=new Scanner(new File(this.filename));
        while(file.hasNextLine()){
            String line=file.nextLine();
            String data[]=line.split(",");
            int studentid= Integer.parseInt(data[0]);
            String name=data[1];
            double finalmarks=Double.parseDouble(data[2]);
            double midmarks=Double.parseDouble(data[3]);
            double classperformance=Double.parseDouble(data[4]);
            Student s=new Student(studentid, name, finalmarks, midmarks, classperformance);
            students.add(s);
        }
        return students;
    }
}
