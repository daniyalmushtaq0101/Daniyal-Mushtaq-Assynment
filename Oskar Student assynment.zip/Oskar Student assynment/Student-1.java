import java.util.Scanner;
public class Student {
    private int studentid;
    private String name;
    private double finalmarks;
    private double midmarks;
    private double classperformance;
    public Student(int studentid,String name,double finalmarks,double midmarks,double classperformance){
        this.studentid=studentid;
        this.name=name;
        this.finalmarks=finalmarks;
        this.midmarks=midmarks;
        this.classperformance=classperformance;
    }
    public Student inputStudent(Scanner sc){
        System.out.println("Enter Student Id!!");
        this.studentid=sc.nextInt();
        System.out.println("Enter Student name");
        this.name=sc.nextLine();
        System.out.println("Enter Student final marks (0-50)");
        this.finalmarks=sc.nextDouble();
        System.out.println("Enter Student mid marks (0-25)");
        this.midmarks=sc.nextDouble();
        System.out.println("Enter Student class performance (0-25) ");
        this.classperformance=sc.nextDouble();
        Student s=new Student(this.studentid, this.name, this.finalmarks, this.midmarks, this.classperformance);
        return  s;
    }
    public double gpacalculator(){
        double gpa=((this.finalmarks+this.midmarks+this.classperformance)/100)*5;
        return gpa;
    }
    public int getid(){
        return this.studentid;
    }
    public String getname(){
        return this.name;
    }
    public String toString(){
        return "Student Id="+this.studentid+"  ,Student name="+this.name+"  ,Student final marks="+this.finalmarks+"  ,Student mid marks="+this.midmarks+" ,Student class performance="+this.classperformance;
    }
}
